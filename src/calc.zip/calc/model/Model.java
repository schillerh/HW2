package calc.model;

public interface Model {
	void notifyChanged(ModelEvent e);
}
